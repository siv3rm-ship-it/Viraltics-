import express from 'express';
import { processApifyWebhook } from '../controllers/apify.controller';
import { processPaddleWebhook } from '../controllers/payments.controller';
const router = express.Router();
router.post('/apify', processApifyWebhook);
router.post('/paddle', express.urlencoded({ extended: true }), processPaddleWebhook);
export default router;
