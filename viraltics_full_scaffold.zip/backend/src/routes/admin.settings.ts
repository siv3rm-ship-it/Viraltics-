import express from 'express';
import getDb from '../lib/db';
import { SettingsService } from '../lib/settings.service';
const router = express.Router();

router.get('/', async (req, res) => {
  const db = getDb();
  const rows = await db('system_settings').select();
  // do not return raw encrypted values in API - return masked
  const masked = rows.map(r => ({ key: r.key, value: r.encrypted ? (r.value ? '****' : null) : r.value, encrypted: r.encrypted }));
  res.json({ settings: masked });
});

router.post('/', async (req, res) => {
  const db = getDb();
  const { key, value, encrypted } = req.body;
  await SettingsService.set(db, key, value, encrypted !== false);
  res.json({ ok: true });
});

export default router;
