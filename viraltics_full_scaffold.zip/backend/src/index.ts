import app from './app';
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Viraltics API listening on port ${PORT}`);
});
