import axios from 'axios';
import getDb from '../lib/db';
import { SettingsService } from '../lib/settings.service';

const OPENAI_URL = 'https://api.openai.com/v1/chat/completions';
export const OpenAIService = {
  async analyze(inputJson: any, language = 'en') {
    const db = getDb();
    const apiKey = await SettingsService.get(db, 'OPENAI_API_KEY');
    if(!apiKey) throw new Error('OpenAI key not configured');
    const systemPrompt = language === 'ar' ? "أنت مساعد Viraltics..." : "You are Viraltics AI assistant...";
    const messages = [
      { role: 'system', content: systemPrompt + " ALWAYS OUTPUT JSON ONLY matching schema." },
      { role: 'user', content: JSON.stringify(inputJson) }
    ];
    const resp = await axios.post(OPENAI_URL, {
      model: 'gpt-4o-mini',
      temperature: 0.0,
      messages,
      max_tokens: 1200
    }, {
      headers: { Authorization: `Bearer ${apiKey}` }
    });
    return resp.data;
  }
};
