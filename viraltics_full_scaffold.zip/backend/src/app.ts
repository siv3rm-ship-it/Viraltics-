import express from 'express';
import bodyParser from 'body-parser';
import settingsRouter from './routes/admin.settings';
import webhooksRouter from './routes/webhooks';
import apiRouter from './routes/api';
import { initDb } from './lib/db';
const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize DB connection
initDb().then(() => console.log("DB initialized")).catch(err => console.error("DB init error", err));

app.use('/admin/settings', settingsRouter);
app.use('/webhooks', webhooksRouter);
app.use('/api', apiRouter);

export default app;
