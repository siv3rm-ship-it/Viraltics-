import { Request, Response } from 'express';
export async function processPaddleWebhook(req: Request, res: Response) {
  try {
    const data = req.body;
    // TODO: verify Paddle p_signature per Paddle docs
    console.log('Paddle webhook', data);
    res.status(200).send('ok');
  } catch(err) {
    console.error(err);
    res.status(500).send('error');
  }
}
