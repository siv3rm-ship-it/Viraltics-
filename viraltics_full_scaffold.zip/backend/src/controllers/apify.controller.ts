import { Request, Response } from 'express';
export async function processApifyWebhook(req: Request, res: Response) {
  try {
    const body = req.body;
    // TODO: verify signature with WEBHOOK_SECRET if configured
    // If ACTOR.RUN.SUCCEEDED -> enqueue process job or call processing routine
    console.log('Apify webhook received', body);
    res.status(200).send('ok');
  } catch (err) {
    console.error(err);
    res.status(500).send('error');
  }
}
