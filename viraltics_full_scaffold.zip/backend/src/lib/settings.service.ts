import knex from '../lib/db';
import crypto from 'crypto';
const ALGO = 'aes-256-gcm';
const MASTER_KEY = (process.env.JWT_SECRET || 'change_this_to_long_random_value').slice(0,32);

function encrypt(text: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, Buffer.from(MASTER_KEY), iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return iv.toString('hex') + ':' + tag.toString('hex') + ':' + encrypted.toString('hex');
}
function decrypt(payload: string) {
  const [ivHex, tagHex, encHex] = payload.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const tag = Buffer.from(tagHex, 'hex');
  const encryptedText = Buffer.from(encHex, 'hex');
  const decipher = crypto.createDecipheriv(ALGO, Buffer.from(MASTER_KEY), iv);
  decipher.setAuthTag(tag);
  const decrypted = Buffer.concat([decipher.update(encryptedText), decipher.final()]);
  return decrypted.toString('utf8');
}

export const SettingsService = {
  async get(knexInstance: any, key: string) {
    const row = await knexInstance('system_settings').where({key}).first();
    if(!row) return null;
    if(row.encrypted) return decrypt(row.value);
    return row.value;
  },
  async set(knexInstance: any, key: string, value: string, encrypted = true) {
    const v = encrypted ? encrypt(value) : value;
    await knexInstance('system_settings').insert({key, value: v, encrypted}).onConflict('key').merge();
    return true;
  },
  async all(knexInstance: any) {
    const rows = await knexInstance('system_settings').select();
    return rows.map(r => ({ key: r.key, value: r.encrypted ? decrypt(r.value) : r.value }));
  }
};
