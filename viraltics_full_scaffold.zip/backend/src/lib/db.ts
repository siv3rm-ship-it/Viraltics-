import knex from 'knex';
let db: any = null;
export async function initDb() {
  if(db) return db;
  const DATABASE_URL = process.env.DATABASE_URL!;
  db = knex({ client: 'pg', connection: DATABASE_URL, pool: { min: 2, max: 10 }});
  // simple ping
  await db.raw('select 1+1 as result');
  return db;
}
export default function getDb() { return db; }
