import Link from 'next/link';
export default function Home() {
  return (
    <main style={{padding:40}}>
      <h1>Viraltics</h1>
      <p>Social analytics platform scaffold. Login to dashboard after deploying backend.</p>
      <Link href="/dashboard">Go to Dashboard</Link>
    </main>
  );
}
