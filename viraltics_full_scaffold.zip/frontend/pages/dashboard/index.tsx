export default function Dashboard() {
  return (
    <main style={{padding:40}}>
      <h2>Dashboard</h2>
      <p>Welcome to Viraltics Dashboard (scaffold)</p>
    </main>
  );
}
