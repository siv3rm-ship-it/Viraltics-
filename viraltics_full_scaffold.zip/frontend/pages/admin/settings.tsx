import { useState, useEffect } from 'react';
import axios from 'axios';
export default function AdminSettings() {
  const [settings, setSettings] = useState([]);
  const [key, setKey] = useState('');
  const [value, setValue] = useState('');
  useEffect(()=>{ fetch(); },[]);
  async function fetch() {
    const resp = await axios.get('/admin/settings');
    setSettings(resp.data.settings);
  }
  async function save() {
    await axios.post('/admin/settings', { key, value, encrypted: true });
    setKey(''); setValue(''); fetch();
  }
  return (
    <div style={{padding:20}}>
      <h1>Admin Settings</h1>
      <div>
        <input placeholder="key" value={key} onChange={e=>setKey(e.target.value)} />
        <input placeholder="value" value={value} onChange={e=>setValue(e.target.value)} />
        <button onClick={save}>Save</button>
      </div>
      <h3>Existing</h3>
      <ul>{settings.map(s => <li key={s.key}>{s.key}: {s.value}</li>)}</ul>
    </div>
  );
}
